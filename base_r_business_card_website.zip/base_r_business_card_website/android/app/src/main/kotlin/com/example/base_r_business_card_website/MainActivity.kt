package com.example.base_r_business_card_website

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
